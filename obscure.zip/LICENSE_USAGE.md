# License Usage Terms

You may use this code under the following conditions:

✅ Permitted:
- Personal use
- Academic or independent security research
- Non-commercial education or demonstration

🚫 Not permitted:
- Commercial use
- Integration into paid products
- Sale or resale in any form

To discuss commercial licensing, please contact: machinetherapist@gmail.com
